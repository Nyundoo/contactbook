<form id="form-delete" method="POST" style="display: none">
    @csrf
    @method('DELETE')
</form>