<?php echo e($slot); ?>

<?php /**PATH C:\Users\Creative 2\eclipse-workspace\laravel\contact-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>