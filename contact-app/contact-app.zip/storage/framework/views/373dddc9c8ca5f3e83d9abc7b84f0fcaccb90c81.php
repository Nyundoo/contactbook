

<?php $__env->startSection('title', 'Contact App | All Companies'); ?>

<?php $__env->startSection('content'); ?>
<main class="py-5">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
                <div class="card-header card-title">
                  <div class="d-flex align-items-center">
                    <h2 class="mb-0">All Companies</h2>
                    <div class="ml-auto">
                      <a href="<?php echo e(route('companies.create')); ?>" class="btn btn-success"><i class="fa fa-plus-circle"></i> Add New</a>
                    </div>
                  </div>
                </div>
              <div class="card-body">
                <?php echo $__env->make('companies._filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                <table class="table table-striped table-hover">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Name</th>
                      <th scope="col">Address</th>
                      <th scope="col">Email</th>
                      <th scope="col">Contacts</th>
                      <th scope="col">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php if($message = session('message')): ?>
                      <div class="alert alert-success"><?php echo e($message); ?></div>
                    <?php endif; ?>
                  <?php if($companies->count()): ?>
                    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                      <th scope="row"><?php echo e($index + $companies->firstItem()); ?></th>
                      <td><?php echo e($company->name); ?></td>
                      <td><?php echo e($company->address); ?></td>
                      <td><?php echo e($company->email); ?></td>
                      <td><?php echo e($company->contacts->count()); ?></td>
                      <td width="150">
                        <a href="<?php echo e(route('companies.show', $company->id)); ?>" class="btn btn-sm btn-circle btn-outline-info" title="Show"><i class="fa fa-eye"></i></a>
                        <a href="<?php echo e(route('companies.edit', $company->id)); ?>" class="btn btn-sm btn-circle btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></a>
                        <a href="<?php echo e(route('companies.destroy', $company->id)); ?>" class="btn-delete btn btn-sm btn-circle btn-outline-danger" title="Delete"><i class="fa fa-times"></i></a>
                      </td> 
                    </tr> 
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php echo $__env->make('layouts._delete-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                  </tbody>
                </table> 

                <?php echo e($companies->appends(request()->only('company_id'))->links()); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nyundoo\eclipse-workspace\laravel\contact-app\resources\views/companies/index.blade.php ENDPATH**/ ?>