

<?php $__env->startSection('content'); ?>
<main class="py-5">
      <div class="container">
        <div class="row justify-content-md-center">
          <div class="col-md-8">
            <div class="card">
              <div class="card-header card-title">
                <strong>Add New Company</strong>
              </div>           
              <div class="card-body">
                <form action="<?php echo e(route('companies.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('companies._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Contact App | Add new company'); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Nyundoo\eclipse-workspace\laravel\contact-app\resources\views/companies/create.blade.php ENDPATH**/ ?>