<form id="form-delete" method="POST" style="display: none">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
</form><?php /**PATH C:\Users\Nyundoo\eclipse-workspace\laravel\contact-app\resources\views/layouts/_delete-form.blade.php ENDPATH**/ ?>