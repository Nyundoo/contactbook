<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title><?php echo $__env->yieldContent('title', 'Contact App'); ?></title>

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Varela+Round">

    <!-- Bootstrap -->
  <?php echo $__env->yieldContent('styles'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
  </head>
  <body>
    <!-- navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
      <div class="container">
        <a class="navbar-brand text-uppercase" href="<?php echo e(url('/')); ?>">            
            <strong>Contact</strong> App
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-toggler" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
            
        <!-- /.navbar-header -->
        <div class="collapse navbar-collapse" id="navbar-toggler">
          <?php if(auth()->guard()->check()): ?>
            <ul class="navbar-nav">
              <li class="nav-item <?php echo e(request()->is('companies*') ? 'active' : ''); ?>"><a href="<?php echo e(route('companies.index')); ?>" class="nav-link">Companies</a></li>
              <li class="nav-item <?php echo e(request()->is('contacts*') ? 'active' : ''); ?>"><a href="<?php echo e(route('contacts.index')); ?>" class="nav-link">Contacts</a></li>
            </ul>
          <?php endif; ?>

          <ul class="navbar-nav ml-auto">
            <?php if(auth()->guard()->guest()): ?>
              <li class="nav-item mr-2"><a href="<?php echo e(route('login')); ?>" class="btn btn-outline-secondary">Login</a></li>
              <li class="nav-item"><a href="<?php echo e(route('register')); ?>" class="btn btn-outline-primary">Register</a></li>
            <?php else: ?>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <?php echo e(auth()->user()->fullName()); ?>

                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="<?php echo e(route('settings.profile.edit')); ?>">Settings</a>
                  <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                </div>
              </li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
  </body>
</html><?php /**PATH C:\Users\Creative 2\eclipse-workspace\laravel\contact-app\resources\views/layouts/main.blade.php ENDPATH**/ ?>