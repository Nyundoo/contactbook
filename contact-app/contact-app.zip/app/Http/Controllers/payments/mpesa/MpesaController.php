<?php

namespace App\Http\Controllers\payments\mpesa;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MpesaController extends Controller
{
    public function getAccessToken() {
        $url = env('MPESA_ENV') == 0
        ? 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials'
        : 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials',
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => '',
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 0,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => 'GET',
          CURLOPT_HTTPHEADER => array(
            'Authorization: Basic THlMUXRHTDdMVHdNdElHVGZwWEVtWUZrbURJRW9SZ0M6NnBNTjJDRFQ4Q0RKZXNDYQ==',
            'Cookie: incap_ses_459_2742146=qaCEUnio2DEht0QL1bJeBlMn0WIAAAAAxyaYcKX0WMr0nReGv+QcPA==; visid_incap_2742146=92kBY6GbRy+ZnPXCEuELpZ+A0GIAAAAAQUIPAAAAAAD0IhNWcIXu5STej309CDIk'
          ),
        ));
        
        $response = curl_exec($curl);
        
        curl_close($curl);
        // echo $response;
    }

    public function registerURLs(){
      $consumerKey = 'LyLQtGL7LTwMtIGTfpXEmYFkmDIEoRgC'; //Fill with your app Consumer Key
      $consumerSecret = '6pMN2CDT8CDJesCa'; // Fill with your app Secret
    
      $headers = ['Content-Type:application/json; charset=utf8'];
    
      $url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
    
      $curl = curl_init($url);
      curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
      curl_setopt($curl, CURLOPT_HEADER, FALSE);
      curl_setopt($curl, CURLOPT_USERPWD, $consumerKey.':'.$consumerSecret);
      $result = curl_exec($curl);
      $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
      $result = json_decode($result);
    
      $access_token = $result->access_token;
    
    // 	echo $access_token;
    
      curl_close($curl);
    
      $url = 'https://sandbox.safaricom.co.ke/mpesa/c2b/v1/registerurl';
    
      $shortCode = '60502'; // provide the short code obtained from your test credentials
    
      /* This two files are provided in the project. */
      $confirmationUrl = 'https://imevolimited.co.ke/test/confirmation_url.php'; // path to your confirmation url. can be IP address that is publicly accessible or a url
      $validationUrl = 'https://imevolimited.co.ke/test/validation.php'; // path to your validation url. can be IP address that is publicly accessible or a url
    
    
    
      $curl = curl_init();
      curl_setopt($curl, CURLOPT_URL, $url);
      curl_setopt($curl, CURLOPT_HTTPHEADER, array('Content-Type:application/json','Authorization:Bearer '.$access_token)); //setting custom header
    
    
      $curl_post_data = array(
        //Fill in the request parameters with valid values
        'ShortCode' => $shortCode,
        'ResponseType' => 'Completed',
        'ConfirmationURL' => $confirmationUrl,
        'ValidationURL' => $validationUrl
      );
    
      $data_string = json_encode($curl_post_data);
    
      curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($curl, CURLOPT_POST, true);
      curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
    
      $response = curl_exec($curl);
      print_r($response);
    
      // echo $response;
}
}
